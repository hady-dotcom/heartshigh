# Guiding Home Learning

This folder is a copy of the learner app for demos.

Join code: PARENT-DEMO
Opening index.html starts the first film. You are already in.

1. Open index.html in a browser. You can double-click it.
2. The films play in order, from 1 to the last.
3. Your place is saved in this browser only. It is not sent anywhere.
4. When a film ends, the next one starts after a short pause. Press Next if it does not.
5. If a film is locked, you will see "Watch the previous one first."
6. Watch the films in order.

You do not need an account for this copy.
